/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [],
  theme: {
    extend: {},
    other_options: "",
    another_options: ""
  },
  plugins: [],
}
