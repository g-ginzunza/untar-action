/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [],
  theme: {
    extend: {},
    other_options: "",
    another_options: "",
    another_options2: "",
    another_options3: "",
    another_options4: "",
  },
  plugins: [],
}
